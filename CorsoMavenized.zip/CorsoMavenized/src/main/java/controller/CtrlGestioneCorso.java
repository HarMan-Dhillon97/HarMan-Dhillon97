package controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import util.UDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.*;
import model.dao.AulaDAO;
import model.entity.*;


@WebServlet("/CtrlGestioneCorso")
public class CtrlGestioneCorso extends HttpServlet{
	
	
	private static final long serialVersionUID = 1L;
	private CorsoService oCorsoService = new CorsoService();
	private DocenteService oDocenteService = new DocenteService();
	private AulaService oAulaService = new AulaService();
	private DiscenteService oPartecipanteService = new DiscenteService();
	private UDate date = new UDate();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CtrlGestioneCorso() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String azione = request.getParameter("cmdAzione");
		if(azione == null)
		{
			visualizzaElenco(request, response);
		}
		else if(azione.equals("Torna alla Home"))
		{
			getServletContext().getRequestDispatcher("/CtrlMain").forward(request, response);
		}
		else if(azione.equals("Nuovo"))
		{
			nuovoCorso(request, response);
		}
		else if(azione.equals("Torna ai corsi"))
		{
			visualizzaElenco(request,response);
		}	
		else if(azione.equals("Registra"))
		{
			salvaCorso(request,response);
			visualizzaElenco(request, response);
		}
		else if(azione.equals("Partecipanti"))
		{
		
			partecipanti(request, response);
		}
		else if(azione.equals("Aggiungi")) {
			
		}
		
	}
	
	private void aggiungiPartecipanti(HttpServletRequest request, HttpServletResponse response) {
		Corso oCorso = new Corso();
		oCorso.setPartecipanti(null);
	}

	private void partecipanti(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				List<Discente> elenco = oPartecipanteService.findAll();
				request.setAttribute("elencoPartecipanti", elenco);
				//Definizione di un oggetto della classeServletContext
				ServletContext oContesto = getServletContext();
				//Definizione di un oggetto per la pubblicazione della PGS
				RequestDispatcher oDispatcher = oContesto.getRequestDispatcher("" +
						"/ArchivioPartecipanti/partecipanti.jsp");
				oDispatcher.forward(request, response);
		
	}


	private void salvaCorso(HttpServletRequest request, HttpServletResponse response){
		((Corso) request.getSession().getAttribute("beanCorso")).setCorso(request.getParameter("txtCorso"));
		((Corso) request.getSession().getAttribute("beanCorso")).setDurata(request.getParameter("Durata"));
		try {
			((Corso) request.getSession().getAttribute("beanCorso")).setDataInizio(UDate.ctrlData(request.getParameter("dataInizio")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		((Corso) request.getSession().getAttribute("beanCorso")).setDocente((oDocenteService.findById(Integer.parseInt(request.getParameter("cboDocente")))));
		((Corso) request.getSession().getAttribute("beanCorso")).setAula((oAulaService.findById(Integer.parseInt(request.getParameter("cboAula")))));		((Corso) request.getSession().getAttribute("beanCorso")).setDurata(request.getParameter("Durata"));
		try {
			((Corso) request.getSession().getAttribute("beanCorso")).setDataInizio(UDate.ctrlData(request.getParameter("dataInizio")));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		((Corso) request.getSession().getAttribute("beanCorso")).setDocente((oDocenteService.findById(Integer.parseInt(request.getParameter("cboDocente")))));
		((Corso) request.getSession().getAttribute("beanCorso")).setAula((oAulaService.findById(Integer.parseInt(request.getParameter("cboAula")))));
		if(((Corso) request.getSession().getAttribute("beanCorso")).getChiave() == 0)
			oCorsoService.persist(((Corso) request.getSession().getAttribute("beanCorso")));
		else
			oCorsoService.update(((Corso) request.getSession().getAttribute("beanCorso")));
				
	}
		
	
	private void nuovoCorso(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Corso oCorso = new Corso();
		HttpSession oSessione = request.getSession();
		oSessione.setAttribute("beanCorso", oCorso);
		request.setAttribute("elencoDocenti", oDocenteService.findAll());
		request.setAttribute("elencoAule", oAulaService.findAll());
		request.setAttribute("elencoPartecipanti", ((Corso) request.getSession().getAttribute("beanCorso")).getPartecipanti());
		getServletContext().getRequestDispatcher("/GestioneCorso/PgsNuovoModificaCorso.jsp").forward(request, response);
	}
	
	


	
 
	private void visualizzaElenco(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Corso> elenco = oCorsoService.findAll();
		request.setAttribute("elencoCorsi", elenco);
		//oggetto della classeServletContext
		ServletContext oContesto = getServletContext();
		//oggetto per la pubblicazione della PGS
		RequestDispatcher oDispatcher = oContesto.getRequestDispatcher
				(""+"/GestioneCorso/PgsGestioneCorso.jsp");
		oDispatcher.forward(request, response);
		}

}