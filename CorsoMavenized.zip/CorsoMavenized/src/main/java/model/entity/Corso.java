package model.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import util.UDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name="Corso")
public class Corso {
	
	public static final String PROPERTY_idcorso = "idcorso";
	public static final String PROPERTY_iddocente = "iddocente";
	public static final String PROPERTY_idaula = "idaula";
	public static final String PROPERTY_corso = "corso";
	public static final String PROPERTY_durata = "durata";
	public static final String PROPERTY_datainizio = "datainizio";
	public static final String PROPERTY_partecipanti = "partecipanti";
	
	@Column(name="idcorso")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int chiave;
	
	@Column(name="corso")
	private String corso;
	
	@Column(name="durata")
	private String durata;
	
	@Column(name="datainizio")
	private Date dataInizio;
	
	@ManyToOne
	@JoinColumn(name = "iddocente")
	private Docente oDocente;
	
	@ManyToOne
	@JoinColumn(name = "idaula")
	private Aula oAula;
	
	@ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
	@Fetch(FetchMode.SUBSELECT)
	@JoinTable(name = "CorsoDiscente", joinColumns = {@JoinColumn(name = "IdCorso")}, inverseJoinColumns = {
			@JoinColumn(name = "IDDiscente")})
	private List<Discente> partecipanti = new ArrayList<Discente>();

	public int getChiave() {
		return chiave;
	}

	public void setChiave(int chiave) {
		this.chiave = chiave;
	}

	public String getCorso() {
		return corso;
	}

	public void setCorso(String corso) {
		this.corso = corso;
	}

	public String getDurata() {
		return durata;
	}

	public void setDurata(String durata) {
		this.durata = durata;
	}

	public Date getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(Date dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Docente getDocente() {
		return oDocente;
	}

	public void setDocente(Docente docente) {
		this.oDocente = docente;
	}

	public Aula getAula() {
		return oAula;
	}

	public void setAula(Aula Aula) {
		this.oAula = Aula;
	}

	public List<Discente> getPartecipanti() {
		return partecipanti;
	}

	public void setPartecipanti(Discente partecipante) {
		this.partecipanti.add(partecipante);
	}

	
}