package model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name="Docente")
	public class Docente {
		
		@Column(name="iddocente")
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int chiave;
		
		@Column(name="cognome")
		private String cognome;
		
		@Column(name="nome")
		private String nome;

		public int getChiave() {
			return chiave;
		}

		public void setChiave(int chiave) {
			this.chiave = chiave;
		}

		public String getCognome() {
			return cognome;
		}

		public void setCognome(String cognome) {
			this.cognome = cognome;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}
	}


