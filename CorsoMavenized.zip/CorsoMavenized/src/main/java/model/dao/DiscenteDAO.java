package model.dao;

import model.entity.Discente;

public class DiscenteDAO extends AbstractDAO<Discente> {
	
	@Override
	public Class<Discente> getPersistentClass(){
		return Discente.class;
	}
}
