package model.dao;

import model.entity.Corso;

public class CorsoDAO extends AbstractDAO<Corso>{

	@Override
	public Class<Corso> getPersistentClass() {
		// TODO Auto-generated method stub
		//return null;// ritorna NULL pointer exception
		return Corso.class;
	}
	

}
