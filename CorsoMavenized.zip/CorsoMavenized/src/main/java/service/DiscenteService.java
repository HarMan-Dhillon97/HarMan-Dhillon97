package service;

import model.entity.Discente;
import model.dao.*;

public class DiscenteService extends AbstractService<DiscenteDAO,Discente>{

	@Override
	public DiscenteDAO createDAO() {
		// TODO Auto-generated method stub
		return new DiscenteDAO();
	}
}
