package service;

import model.dao.AulaDAO;
import model.entity.Aula;

public class AulaService extends AbstractService<AulaDAO, Aula>{

	@Override
	public AulaDAO createDAO() {
		// TODO Auto-generated method stub
		return new AulaDAO();
	}

}
