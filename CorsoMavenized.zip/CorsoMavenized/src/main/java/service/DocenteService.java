package service;

import model.entity.Docente;
import model.dao.*;

public class DocenteService extends AbstractService<DocenteDAO, Docente>{

	@Override
	public DocenteDAO createDAO() {
		// TODO Auto-generated method stub
		return new DocenteDAO();
	}
}
