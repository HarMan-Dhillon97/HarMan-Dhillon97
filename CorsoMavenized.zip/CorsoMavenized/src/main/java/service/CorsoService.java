package service;

import model.dao.CorsoDAO;
import model.entity.Corso;

public class CorsoService extends AbstractService<CorsoDAO, Corso> {

	@Override
	public CorsoDAO createDAO() {
		// TODO Auto-generated method stub
		return new CorsoDAO();
	}

		
}
